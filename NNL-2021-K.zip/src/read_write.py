from tkinter.constants import NONE
from typing import List
import images as img
import tags
import json
from tkinter import filedialog

""" This file is all about reading and writing files """


def find_image(img_path, list_img: List[img.Img]):
    for i in list_img:
        if img_path == i.path:
            return i


def read_file(list_img: List[img.Img]):
    """
        Opening of json file which store all the annotations.
        We browse them all and we assign them respectively to each of the images
    """
    file = filedialog.askopenfile(filetypes=[('JSON', '.json')])
    if file == None:
        return
    try:
        D = json.load(file)
    except UnicodeDecodeError:
        return
    for elt in D:
        img = find_image(elt[0], list_img)
        for tag_name in elt[1]:
            for coor in elt[1][tag_name]:
                img.add_tag(tag_name, coor[0][0],
                            coor[0][1], coor[1][0], coor[1][1], None)
    file.close()


def write_file(list_img: List[img.Img]):
    """ We browe all annotations and store it in a json file """
    file = filedialog.asksaveasfile(
        defaultextension='.json', filetypes=[('JSON', '.json')],
        initialfile='output.json')
    if file == None:
        return
    L = []
    for elt in list_img:
        L.append([elt.path, elt.tag_of_points])
    json.dump(L, file)
    file.close()


if __name__ == '__main__':
    tag_list = tags.Tag(img.open_files())
    img_list = tag_list.imgs
    for i in img_list:
        i.set_tag_list(tag_list)
    # img_list[0].add_tag('tipo', 4, 5, 999, 888)
    # img_list[0].add_tag('tipo', 0, 2, 444, 555)
    # img_list[0].add_tag('tipo', 1000, 1000, 2000, 2000)
    # img_list[0].add_tag('t1', 0, 2, 333, 222)
    # img_list[1].add_tag('ffff', 0, 99, 111, 666)
    # write_file(img_list, "file_name")
    # tag_list.remove('tipo')
    # tag_list.remove('ffff')
    # tag_list.remove('t1')
    # read_file('file_name', img_list)
