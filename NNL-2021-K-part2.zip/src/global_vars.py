KERA_PRED_FOLDER = '../pre/keras_pred_folder'
crop_dir = '../pre/crop_img'
test_img = '../pre/test_img'
json_test = '../pre/annotation/test.json'
path_to_image = "../img"
test_for_help = '../pre/text/'

image_size = (180, 180)
epochs = 15
img_ext = '*.jpg *.png *.jpeg'
